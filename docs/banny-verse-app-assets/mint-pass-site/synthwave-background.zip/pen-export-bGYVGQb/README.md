# I made this synthwave background in CSS (except for the mountains)

A Pen created on CodePen.io. Original URL: [https://codepen.io/RockStarwind/pen/bGYVGQb](https://codepen.io/RockStarwind/pen/bGYVGQb).

I originally intended for this background to be part of the latest :has emulation game I was working on. @PropJockey had trouble loading the game because of the expensive background and recommended I made it its own thing, so here it is!

Apologies to mobile users and anyone with screen resolutions I'm not intimately familiar with. This is one of those rare moments where I make CSS art and I had trouble finding the right CSS units to use for the job. Hope you love it nonetheless!  

~ @RockStarwind