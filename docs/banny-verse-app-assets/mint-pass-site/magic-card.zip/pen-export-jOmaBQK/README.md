# Magic Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/gayane-gasparyan/pen/jOmaBQK](https://codepen.io/gayane-gasparyan/pen/jOmaBQK).

Yet another glowing card