# [3D] Synth Canyon Run

A Pen created on CodePen.io. Original URL: [https://codepen.io/jhnsnc/pen/GRJeOWZ](https://codepen.io/jhnsnc/pen/GRJeOWZ).

I wanted to do some experimentation with manipulating geometries and layering several simple shader effects, and this is what I came up with. Enjoy!

The Soundcloud embed is just there for ambiance. Not my music; just something that seemed fitting.