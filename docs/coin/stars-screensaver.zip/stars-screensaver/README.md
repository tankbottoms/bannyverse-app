# Stars screensaver

A Pen created on CodePen.io. Original URL: [https://codepen.io/nodws/pen/pejBNb](https://codepen.io/nodws/pen/pejBNb).

Space speed adventure in Animated Canvas :P