# GBP

A Pen created on CodePen.io. Original URL: [https://codepen.io/atsignhandle/pen/PoQmEPV](https://codepen.io/atsignhandle/pen/PoQmEPV).

A Great British Pound coin spinning, created with 3D transforms and animation in CSS. I was reminded of old PS1 loading screens, where they just spun the disc forever, and never actually loaded a game. Perhaps that was just my experience.

Webkit only for now, just because.
