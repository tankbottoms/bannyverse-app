<script>
</script>

<section>
  <h1>
    "The will to win, the desire to succeed, the urge to reach your full
    potential... these are the keys that will unlock the door to the
    bannyverse."
  </h1>
</section>

<style>
  section {
    background-image: url("/images/mid-section-one-bg.svg");
    background-repeat: no-repeat;
    margin: 0;
    padding: 15rem 0;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    /* min-height: 931px; */
  }

  h1 {
    color: #fff;
    max-width: 982px;
    font-size: 50px;
    line-height: 60px;
    text-shadow: 0px 0px 15px #000000;
    margin: 0;
  }
  @media only screen and (min-device-width: 320px) and (max-device-width: 480px) and (-webkit-min-device-pixel-ratio: 2) {
    h1 {
  
      font-size: 40px;
      margin-bottom: 10rem;
       padding: 2rem;
      
    }

    section {
      padding: 0;
    }
  }

  @media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (-webkit-min-device-pixel-ratio: 1) {
    h1 {
      padding: 0 4rem;
      font-size: 45px;
    }
  }
</style>
