//
//  ViewController.h
//  SunVox Player
//
//  Created by Alexander Zolotov on 29.04.13.
//  Copyright (c) 2013 Alexander Zolotov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
