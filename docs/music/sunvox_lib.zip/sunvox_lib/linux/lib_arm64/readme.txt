Minimum system requirements for this version:
Linux (arm64); ARMv8-A (Cortex-A53); glibc 2.28 (2018)